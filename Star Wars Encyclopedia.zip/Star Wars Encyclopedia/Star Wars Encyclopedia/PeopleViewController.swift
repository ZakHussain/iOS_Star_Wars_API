//
//  ViewController.swift
//  Star Wars Encyclopedia
//
//  Created by Zak Hussain on 9/19/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//

import UIKit
import Foundation

class PeopleViewController: UITableViewController {
    var people: [String] = []
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = NSURL(string: "http://swapi.co/api/people")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!, completionHandler: {
            data, response, error in
            do{
                if let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSDictionary {
                    print(jsonResult)
                    if let results = jsonResult["results"] {

                        let resultsArray = results as! NSArray
                       
                        for index in 0 ..< resultsArray.count{
                          self.people.append(resultsArray[index]["name"] as! String)
                            self.tableView.reloadData()
                        }
                    }
                }
            } catch {
                print("something went wrong")
            }
        })
        
        task.resume()
 
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = people[indexPath.row]
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

