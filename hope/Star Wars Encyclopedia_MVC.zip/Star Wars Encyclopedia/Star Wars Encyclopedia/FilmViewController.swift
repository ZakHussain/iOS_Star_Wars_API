//
//  FilmViewController.swift
//  Star Wars Encyclopedia
//
//  Created by Zak Hussain on 9/19/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//

import Foundation
import UIKit

class FilmViewController: UITableViewController{
   
    var film: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

    StarWarsModel.getAllFilms() {
        data, response, error in
            do {
                if let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"]{
                        let resultsArray = results as! NSArray
                        for film in 0 ..< resultsArray.count{
                            self.film.append(resultsArray[film]["title"] as! String)
                            self.tableView.reloadData()
                        }
                    }
                }
            } catch {
                print("Something went wrong")
            }
        }
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return film.count
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell = UITableViewCell()
        cell.textLabel?.text = film[indexPath.row]
        return cell
    }
}